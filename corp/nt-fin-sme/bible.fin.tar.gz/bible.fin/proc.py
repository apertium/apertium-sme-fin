#!/usr/bin/python
# coding=utf-8
# -*- encoding: utf-8 -*-

import sys, codecs, copy, commands, os;

sys.stdin = codecs.getreader('utf-8')(sys.stdin);
sys.stdout = codecs.getwriter('utf-8')(sys.stdout);
sys.stderr = codecs.getwriter('utf-8')(sys.stderr);

printing = False;
for line in sys.stdin.read().split('\n'): #{
	if line.count('<blockquote>') > 0: #{
		printing = True;
		continue;
	#}
	if line.count('</blockquote>') > 0: #{
		printing = False;
		continue;
	#}
	if printing == True: #{
		num = line.split(':')[0].strip();
		line = line.replace('<br>','').strip();
		if line != '': #{
			if line.count('[' + num + ':') >= 1: #{
				print num;
				for i in line.split('[' + num + ':'): #{
					print i;
				#}
				continue;
			#}
			print line;
		#}
	#}
#}
